<?php
echo '<html><head><meta http-equiv="refresh" content="0; url=' . admin_url('admin.php?page=wpsafelink-setup') . '"></head></html>';
?>
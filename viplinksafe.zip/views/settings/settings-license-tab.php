<?php
/**
 * Admin View: License Tab
 *
 * @package WP Safelink
 * @since 5.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wpsaf-license-tab-wrap">
    <div class="wpsaf-license-tab-header">
        <h2>License Management</h2>
        <p class="description">Manage your WP Safelink Pro license activation, status, and deactivation.</p>
    </div>

    <style>
        .wpsaf-license-tab-wrap {
            margin: 0 auto;
            padding: 20px;
        }

        .wpsaf-license-tab-header {
            margin-bottom: 24px;
        }

        .wpsaf-license-tab-header h2 {
            margin: 0 0 6px;
            font-size: 20px;
            color: #1e293b;
        }

        .wpsaf-license-tab-header .description {
            margin: 0;
            color: #64748b;
            font-size: 13px;
        }

        .wpsaf-license-tab-table-wrap {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .wpsaf-license-tab-table-wrap .wpsafelink_license_status_table {
            border: none;
            margin: 0;
        }

        .wpsafelink_license_status_table .spinner {
            visibility: visible;
            float: none;
            margin: 0;
        }

        .wpsafelink_license_status_table mark.yes {
            background: #FFF;
            color: #000;
            padding: 3px 8px;
            border-radius: 3px;
            font-weight: 600;
        }

        .wpsafelink_license_status_table mark.no {
            background: #e74c3c;
            color: #fff;
            padding: 3px 8px;
            border-radius: 3px;
            font-weight: 600;
        }

        .wpsafelink_license_status_table tbody td {
            padding: 10px 12px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .dashicons-update-alt.spin {
            animation: spin 1s linear infinite;
            display: inline-block;
        }

        #wpsaf-modal-confirm:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }

        .wpsaf-license-tab-actions {
            margin-top: 16px;
            display: flex;
            gap: 10px;
        }

        .wpsaf-license-tab-actions .button .dashicons {
            font-size: 16px;
            width: 16px;
            height: 16px;
            line-height: 28px;
            margin-right: 4px;
        }
    </style>

    <!-- License Status Table (server-side rendered) -->
    <div class="wpsaf-license-tab-table-wrap">
        <table class="wpsafelink_license_status_table widefat" id="wpsafelink_license_status_tab" cellspacing="0">
            <?php require wpsafelink_plugin_path() . '/views/settings/license-product-status.php'; ?>
        </table>
    </div>

    <!-- Actions -->
    <div class="wpsaf-license-tab-actions">
        <button type="button" class="button" id="wpsaf-license-tab-refresh">
            <span class="dashicons dashicons-update-alt"></span>
            Refresh Status
        </button>
    </div>

    <!-- Deactivation Modal -->
    <div id="wpsaf-change-modal" class="wpsaf-license-modal" style="display: none;">
        <div class="wpsaf-modal-overlay"></div>
        <div class="wpsaf-modal-container">
            <div class="wpsaf-modal-header">
                <span class="wpsaf-modal-icon"><?php echo "\xe2\x9a\xa0\xef\xb8\x8f"; ?></span>
                <h3>Change License Key</h3>
                <button type="button" class="wpsaf-modal-close" id="wpsaf-modal-close">
                    <span class="dashicons dashicons-no"></span>
                </button>
            </div>

            <div class="wpsaf-modal-body">
                <div class="wpsaf-warning-content">
                    <p class="wpsaf-warning-title">
                        Are you sure you want to change your license key?
                    </p>
                    <p class="wpsaf-warning-description">
                        Changing your license will deactivate the current license on this site.
                    </p>

                    <div class="wpsaf-impact-list">
                        <div class="wpsaf-impact-item">
                            <span class="wpsaf-impact-icon"><?php echo "\xf0\x9f\x93\x8c"; ?></span>
                            <span>Current license will be cleared from this installation</span>
                        </div>
                        <div class="wpsaf-impact-item">
                            <span class="wpsaf-impact-icon"><?php echo "\xf0\x9f\x94\x84"; ?></span>
                            <span>You'll need to enter a new valid license key</span>
                        </div>
                        <div class="wpsaf-impact-item">
                            <span class="wpsaf-impact-icon"><?php echo "\xe2\x9c\xa8"; ?></span>
                            <span>Premium features will be temporarily disabled</span>
                        </div>
                    </div>

                    <div class="wpsaf-reactivation-note">
                        <p>
                            <strong>Note:</strong> You can reuse this license on another site or re-enter it here later.
                        </p>
                    </div>
                </div>
            </div>

            <div class="wpsaf-modal-footer">
                <button type="button" class="wpsaf-button wpsaf-button-secondary" id="wpsaf-modal-cancel">
                    Cancel
                </button>
                <button type="button" class="wpsaf-button wpsaf-button-primary" id="wpsaf-modal-confirm">
                    <span class="dashicons dashicons-edit"></span>
                    Change License
                </button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
jQuery(function($) {
    // Toggle status table visibility
    $(document).on('click', '#wpsaf-status-toggle', function() {
        var $body = $('#wpsaf-status-body');
        var $icon = $('#wpsaf-status-toggle-icon');

        $body.slideToggle(300, function() {
            if ($body.is(':visible')) {
                $icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
            } else {
                $icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
            }
        });
    });

    // Deactivate button → open modal
    $(document).on('click', '#wpsaf-change-license-btn, #wpsafelink_change_license_btn', function(e) {
        e.preventDefault();
        $('#wpsaf-change-modal').fadeIn(300);
    });

    // Modal close handlers
    $(document).on('click', '#wpsaf-modal-close, #wpsaf-modal-cancel', function(e) {
        e.preventDefault();
        $('#wpsaf-change-modal').fadeOut(300);
    });

    // Overlay click to close
    $(document).on('click', '.wpsaf-modal-overlay', function(e) {
        if ($(e.target).hasClass('wpsaf-modal-overlay')) {
            $('#wpsaf-change-modal').fadeOut(300);
        }
    });

    // Confirm deactivation via AJAX
    $(document).on('click', '#wpsaf-modal-confirm', function(e) {
        e.preventDefault();

        var $button = $(this);
        var originalText = $button.html();

        $button.prop('disabled', true).html('<span class="dashicons dashicons-update-alt spin"></span> Processing...');

        $.ajax({
            url: wpsafelink_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wpsafelink_change_license',
                nonce: '<?php echo wp_create_nonce('wpsafelink_change_license'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('#wpsaf-change-modal').fadeOut(300);
                    var successHtml = '<div class="notice notice-success is-dismissible"><p>' + response.data.message + '</p></div>';
                    $('.wpsaf-main-container').prepend(successHtml);
                    window.location.reload();
                } else {
                    alert('Error: ' + (response.data.message || 'Failed to clear license'));
                    $button.prop('disabled', false).html(originalText);
                }
            },
            error: function() {
                alert('Failed to process request. Please try again.');
                $button.prop('disabled', false).html(originalText);
            }
        });
    });

    // Refresh Status button
    $('#wpsaf-license-tab-refresh').on('click', function() {
        var $btn = $(this);
        var $icon = $btn.find('.dashicons');

        $btn.prop('disabled', true);
        $icon.addClass('spin');

        $.ajax({
            url: wpsafelink_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wpsafelink_license_status',
                _wpnonce: wpsafelink_ajax._wpnonce,
                page: 'wpsafelink',
                tab: 'license-tab'
            },
            success: function(response) {
                if (response.status === 'success') {
                    $('#wpsafelink_license_status_tab').html(response.message);
                } else {
                    $('#wpsafelink_license_status_tab').html('<tbody><tr><td colspan="3" style="text-align: center; padding: 20px; color: #dc3232;">Failed to check license status</td></tr></tbody>');
                }
            },
            error: function() {
                $('#wpsafelink_license_status_tab').html('<tbody><tr><td colspan="3" style="text-align: center; padding: 20px; color: #dc3232;">Failed to connect to license server</td></tr></tbody>');
            },
            complete: function() {
                $btn.prop('disabled', false);
                $icon.removeClass('spin');
            }
        });
    });

    // License activation form submit (when license is inactive)
    $(document).on('submit', '#wpsaf-license-form', function(e) {
        e.preventDefault();

        var $form = $(this);
        var $input = $form.find('input[name="wpsafelink_license"]');
        var $submitBtn = $form.find('button[type="submit"]');
        var licenseKey = $input.val();

        if (!licenseKey) {
            $input.focus();
            return;
        }

        var originalBtnHtml = $submitBtn.html();
        $submitBtn.prop('disabled', true).html('<span class="dashicons dashicons-update-alt spin"></span> Validating...');

        $.ajax({
            url: wpsafelink_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wpsafelink_validate_license',
                nonce: '<?php echo wp_create_nonce('wpsafelink_license_activation'); ?>',
                license_key: licenseKey,
                domain: window.location.hostname
            },
            success: function(response) {
                if (response.success) {
                    var successHtml = '<div class="notice notice-success is-dismissible"><p>' + response.data.message + '</p></div>';
                    $('.wpsaf-main-container').prepend(successHtml);
                    window.location.reload();
                } else {
                    alert('Error: ' + (response.data.message || 'License validation failed.'));
                    $submitBtn.prop('disabled', false).html(originalBtnHtml);
                }
            },
            error: function() {
                alert('Failed to connect to license server. Please try again.');
                $submitBtn.prop('disabled', false).html(originalBtnHtml);
            }
        });
    });
});
</script>
